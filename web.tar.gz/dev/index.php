<script>
    window.location.assign("./yourplugs");
</script>