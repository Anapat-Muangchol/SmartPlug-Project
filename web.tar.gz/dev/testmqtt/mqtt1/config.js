host = '10.16.64.14';	// hostname or IP address
//host = 'testbed.informatics.buu.ac.th';	// hostname or IP address
port = 1883;
topic = '/smartplug/18:FE:34:CE:0C:86';		// topic to subscribe to
useTLS = false;
username = 'isdat';
password = 'Qwer1234';
cleansession = true;