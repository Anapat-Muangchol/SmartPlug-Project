/*
 Add page title
 */

document.querySelector("#smart-plug-logo").innerHTML = "<span class='icon-chart3'></span>&nbsp;Summary</h4>"

/*
 Short hand Selector
 */
function select(ele) {
    return document.querySelector(ele);
}

var plug;

/*
 Get all plug from api
 */
var getDetailPlug = function () {
    var callBack = $.Deferred();
    var http = new XMLHttpRequest();
    var url = "../api/api-plug.php";
    var params = "function=getDetailAllPlug";
    http.open("POST", url, true);

//Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    http.onreadystatechange = function () {//Call a function when the state changes.
        if (http.readyState == 4 && http.status == 200) {
            callBack.resolve(JSON.parse(http.responseText));
        }
    };
    http.send(params);
    return callBack.promise();
};


/*
 Generate plug lists
 */
var htmlRender = "",
    divNodePlug = document.createElement("div"),
    indexItem = 0,
    firstIndex = 0;

var wait = getDetailPlug();
wait.then(function (result) {
    plug = result;
    if (plug.status) {
        htmlRender += "<form>";
        plug.lists.forEach(function (item, index) {
            console.log(index);
            indexItem++;
            htmlRender +=
                "<label class='plug-label' for='plug-radio-" + item.plug_id + "'>" +
                "<div id='plug-" + item.plug_id + "' class='panel plug gradient-bg'>" +
                "<div class='panel-body'>" +
                "<input type='radio' onchange='selectPlug(this)' data-plug-id='" + item.plug_id + "' class='plug-radio' name='plugs' id='plug-radio-" + item.plug_id + "' value='" + item.plug_id + "' ";
            if (index === 0) {
                firstIndex = item.plug_id;
                htmlRender += "checked";
            }
            htmlRender +=
                "><b>" + indexItem + " : " + item.plug_name + " at " + item.plug_location + "</b>" +
                "</div>" +
                "</div>" +
                "</label>";
        });
        htmlRender += "</form>";


        divNodePlug.innerHTML = htmlRender;
        childLength = divNodePlug.children.length;

        if (htmlRender) {
            for (var child = 0; child < childLength; child++) {
                document.getElementById('plug-render').appendChild(divNodePlug.firstChild);
            }
            getCurrent();
            document.querySelectorAll(".plug")[0].style.background = "linear-gradient(45deg, #03A9F4 0%, #673AB7 100%)";
        }


    } else {
        alert("Can't query from database.");
    }
});

/*
 Graph
 */
var drawGraph = function (result) {
    var graphRawData = result;
    var generateChartData = function () {
        var callBack = $.Deferred();
        var chartData = [];
        for (var i = 0; i < graphRawData.length; i++) {
            // add data item to the array
            chartData.push({
                date: graphRawData[i].used_time,
                visits: graphRawData[i].used_current
            });
            if (i === graphRawData.length - 1) {
                callBack.resolve(chartData);
            }
        }
        return callBack.promise();
    };
    var chartData = generateChartData();
    chartData.then(function (chartData) {
        var chart = AmCharts.makeChart("chartdiv", {
            "type": "serial",
            "categoryField": "category",
            "dataDateFormat": "YYYY-MM-DD",
            "startDuration": 1,
            "theme": "black",
            "export": {
                "enabled": true
            },
            "categoryAxis": {
                "gridPosition": "start",
                "parseDates": true
            },
            "chartCursor": {
                "enabled": true,
                "fullWidth": true,
                "showNextAvailable": true,
                "valueLineBalloonEnabled": true,
                "valueLineEnabled": true,
                "zoomable": false
            },
            "chartScrollbar": {
                "enabled": true,
                "autoGridCount": true,
                "backgroundAlpha": 1
            },
            "trendLines": [],
            "graphs": [
                {
                    "fillAlphas": 1,
                    "id": "AmGraph-1",
                    "title": "graph 1",
                    "type": "column",
                    "valueField": "usage"
                }
            ],
            "guides": [],
            "valueAxes": [
                {
                    "id": "ValueAxis-1",
                    "title": "Usage(unit)"
                }
            ],
            "allLabels": [],
            "balloon": {},
            "legend": {
                "enabled": true
            },
            "titles": [
                {
                    "id": "Title-1",
                    "size": 15,
                    "text": "March"
                }
            ],
            "dataProvider": [
                {
                    "category": "2014-03-01",
                    "usage": 8
                },
                {
                    "category": "2014-03-02",
                    "usage": 16
                },
                {
                    "category": "2014-03-03",
                    "usage": 2
                },
                {
                    "category": "2014-03-04",
                    "usage": 7
                },
                {
                    "category": "2014-03-05",
                    "usage": 5
                },
                {
                    "category": "2014-03-06",
                    "usage": 9
                },
                {
                    "category": "2014-03-07",
                    "usage": 4
                },
                {
                    "category": "2014-03-08",
                    "usage": 15
                },
                {
                    "category": "2014-03-09",
                    "usage": 12
                },
                {
                    "category": "2014-03-10",
                    "usage": 17
                },
                {
                    "category": "2014-03-11",
                    "usage": 18
                },
                {
                    "category": "2014-03-12",
                    "usage": 21
                },
                {
                    "category": "2014-03-13",
                    "usage": 24
                },
                {
                    "category": "2014-03-14",
                    "usage": 23
                },
                {
                    "category": "2014-03-15",
                    "usage": 24
                },
                {
                    "category": "2014-03-16",
                    "usage": 14
                },
                {
                    "category": "2014-03-15",
                    "usage": 20
                },
                {
                    "category": "2014-03-17",
                    "usage": 23
                },
                {
                    "category": "2014-03-18",
                    "usage": 19
                },
                {
                    "category": "2014-03-19",
                    "usage": 16
                },
                {
                    "category": "2014-03-20",
                    "usage": 7
                },
                {
                    "category": "2014-03-21",
                    "usage": 32
                },
                {
                    "category": "2014-03-22",
                    "usage": 11
                },
                {
                    "category": "2014-03-23",
                    "usage": 33
                },
                {
                    "category": "2014-03-24",
                    "usage": 35
                },
                {
                    "category": "2014-03-25",
                    "usage": 21
                },
                {
                    "category": "2014-03-26",
                    "usage": 24
                },
                {
                    "category": "2014-03-27",
                    "usage": 24
                },
                {
                    "category": "2014-03-28",
                    "usage": 22
                },
                {
                    "category": "2014-03-29",
                    "usage": 26
                },
                {
                    "category": "2014-03-30",
                    "usage": 15
                }, {
                    "category": "2014-03-31",
                    "usage": 22
                }
            ]
        });
        chart.addListener("rendered", zoomChart);
        zoomChart();
        // this method is called when chart is first inited as we listen for "rendered" event
        function zoomChart() {
            // different zoom methods can be used - zoomToIndexes, zoomToDates, zoomToCategoryValues
            chart.zoomToIndexes(chartData.length - 40, chartData.length - 1);
        }
    });
};


/*Generate summary info*/

var getCurrent = function () {
    var ajax = new XMLHttpRequest();
    var params = JSON.stringify({
        plugID: firstIndex,
        outletNumber: 1,
        length: 300
    });
    ajax.open("POST", "summary.php", true);
    //Send the proper header information along with the request
    ajax.setRequestHeader("Content-type", "application/json");
    ajax.onreadystatechange = function () {//Call a function when the state changes.
        if (ajax.readyState == 4 && ajax.status == 200) {
            var JSONRsponse = JSON.parse(ajax.responseText);
            if (JSONRsponse.status) {
                drawGraph(JSONRsponse.lists);
            } else {
                alert("error");
            }
        }
    };
    ajax.send(params);
};
getCurrent();

/*User select a plug*/
var selectPlug = function (ele) {
    var plug = document.querySelectorAll(".plug").length,
        plugID = ele.getAttribute("data-plug-id");

    for (var index = 0; index < plug; index++) {
        if (document.querySelectorAll(".plug-radio")[index].getAttribute("data-plug-id") === plugID) {
            ele.parentNode.parentNode.style.background = "linear-gradient(45deg, #03A9F4 0%, #673AB7 100%)";
        } else {
            document.querySelectorAll(".plug")[index].style.background = "";
        }
    }
};


