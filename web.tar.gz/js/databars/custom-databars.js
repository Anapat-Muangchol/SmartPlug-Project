// Databar
$(function() {
	$('.table-databar').databar();
});