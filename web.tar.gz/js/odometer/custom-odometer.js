window.onload=function(){
	setTimeout(function(){
		appointmentsOdometer.innerHTML = 18;
	}, 500);

	setTimeout(function(){
		projectsOdometer.innerHTML = 371;
	}, 500);

	setTimeout(function(){
		shopOdometer.innerHTML = 286;
	}, 500);

	setTimeout(function(){
		interviewsOdometer.innerHTML = 45;
	}, 500);

	setTimeout(function(){
		salesOdometer.innerHTML = 769;
	}, 500);

	setTimeout(function(){
		tasksOdometer.innerHTML = 38;
	}, 500);
}