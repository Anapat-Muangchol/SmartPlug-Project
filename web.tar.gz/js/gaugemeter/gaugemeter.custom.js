// Gauge Meter
$(function(){
	$(".GaugeMeter").gaugeMeter();
});