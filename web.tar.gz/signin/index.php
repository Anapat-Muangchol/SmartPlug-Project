<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign In - Smart Plug</title>
    <?php require("../bin/include.php");
    if ($_COOKIE['member_id'] || $_SESSION['member_id']) { ?>
        <script>
            window.location.assign("<?php echo $base_url; ?>/yourplugs");
        </script>
        <?php
    }
    ?>
    <!-- Error CSS -->
    <link href="login.css" rel="stylesheet" media="screen">
    <!-- Font Awesome CDN -->
    <script src="https://use.fontawesome.com/b42e023c7b.js"></script>
</head>
<body>
<?php require("../bin/test_con.php"); ?>
<div id="box" class="animated bounceIn">
    <div id="top_header">
        <img src="<?php echo $base_url; ?>/img/logo.png" alt="Arise Admin Dashboard Logo"/>
        <h5>
            Sign in to access to your<br/>
            Plug control panel.
        </h5>
        <p id="err-signin" style="color:red"></p>
    </div>
    <div id="inputs">
        <form id="form-signin">
            <div class="form-block">
                <input type="text" id="email-signin" placeholder="Email" required>
                <span id="err-email" style="display: none" class="help-block"></span>
            </div>
            <div class="form-block">
                <input type="password" id="password-signin" placeholder="Password" required>
                <span id="err-password" style="display: none" class="help-block"></span>
                <button id="show-password-btn" class="btn btn-default" type="button"><span class="icon-eye3"></span></button>
            </div>
            <input type="submit" value="Sign In">
        </form>
    </div>
    <div id="bottom" class="clearfix">
        <a href="<?php echo $base_url; ?>dev/arisethem/createuser">Create account</a>
        <div class="pull-right">
            <label class="switch pull-right">
                <input type="checkbox" id="remember-radio" class="switch-input">
                <span class="switch-label" data-on="Yes" data-off="No"></span>
                <span class="switch-handle"></span>
            </label>
        </div>
        <div class="pull-right">
            <span class="cb-label">Remember</span>
        </div>
    </div>
</div>
<script src="login.js"></script>
</body>
</html>