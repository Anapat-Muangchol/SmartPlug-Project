<?php
require("../../classes/Plug.php");
$plug = new Plug();
$plug->getDetailAllPlug();