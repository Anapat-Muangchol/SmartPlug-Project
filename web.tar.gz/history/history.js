/*
 Add page title
 */

document.querySelector("#smart-plug-logo").innerHTML = "<span class='icon-clock'></span>&nbsp;History</h4>";